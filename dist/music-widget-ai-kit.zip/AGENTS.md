Read README.md and SKILL.md before creating a widget theme.
