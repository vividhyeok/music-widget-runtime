Read README.md and SKILL.md; run scripts/build.py and inspect its output before delivering a .mwidget.
